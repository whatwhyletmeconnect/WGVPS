This Resportory is being used to host my website!

To-do:Make website mobile friendly

Done: Dosis font now works on all devices
